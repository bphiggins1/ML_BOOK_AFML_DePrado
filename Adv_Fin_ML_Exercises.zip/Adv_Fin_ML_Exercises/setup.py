from setuptools import find_packages, setup

setup(
    name='src',
    packages=find_packages(),
    version='0.0.1',
    description='snippets and code from Advances in Fin ML, also some utils',
    author='Blackarbsceo',
    license='MIT',
)


#======================================================================
## setup logger

LOG_FORMAT='%(color)s[%(levelname)s %(asctime)s.%(msecs)03d %(module)s:%(lineno)d]%(end_color)s %(message)s'
LOG_DATE_FORMAT='%Y-%m-%d %I:%M:%S'